'''The number of repetitions is specified by the user.'''

n = int(input('Enter the number of times to repeat: '))
for i in range(n):
    print('This is repetitious!')
