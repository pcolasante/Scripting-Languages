'''A simple function returning a value, used in an expression'''

def f(x):
    return x*x

print(f(3))
print(f(3) + f(4)) 
