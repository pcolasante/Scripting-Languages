temperature = 115  
while temperature > 112: # first while loop code
    print(temperature)
    temperature = temperature - 1

print('The tea is cool enough.')
